# -*- coding: utf-8 -*-
from . import hr_loan_config
from . import hr_loan_acc
from . import account_move_line

